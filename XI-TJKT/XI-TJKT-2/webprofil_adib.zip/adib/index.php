<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Profil Saya</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        .container {
            margin-top: 50px;
            padding: 20px;
            background: white;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 10px #999;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Selamat Menikmati</h1>
        <img src="img/adib.webp" alt="Foto Profil" width="150">
        <img src="img/th.jpg" alt="Foto Profil" width="150">
        <p>بسم الله الرحمن الرحيم
        <p>Nama: Muhammad Adib Koironi</p>
        <p>Kelas: XI TJKT 2</p>
        <p>Hobi: Sesuka Hati</p>
        <p>Absen: 12</p>
        <p>SEBE NYENI MASSSSEHHHE</P>
    </div>
</body>

</html>