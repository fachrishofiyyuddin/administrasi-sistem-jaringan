<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Profil Saya</title>
    <style>
        body {
            font-family: Arial, bold;
            background-color:rgb(99, 99, 99);
            text-align: center;
        }

        .container {
            margin-top: 50px;
            padding: 20px;
            background: white;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 10px #999;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Welcome to My Profile</h1>
        <img src="img/foto1.png" alt="Foto Profil" width="150">

       <p>Nama: Yuhda Sabila</p>
        <p>Kelas: XI TJKT 2</p>
        <p>Hobi: improve skils</p>
        <p>absen: 25</p>
    </div>
</body>

</html>