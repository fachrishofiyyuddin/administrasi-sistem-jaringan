<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Profil Saya</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        .container {
            margin-top: 50px;
            padding: 20px;
            background: white;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 10px #999;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Selamat Datang di Web Profil Saya</h1>
        <img src="img/rafky.jpg" alt="Foto Profil" width="250">
        <p>Nama: Muhammad rafky khoirur rizqi</p>
        <p>Kelas: XI TJkT 2</p>
        <p>Hobi: Memancing</p>
        <p>No. Absen: 18</p>
    </div>
</body>

</html>